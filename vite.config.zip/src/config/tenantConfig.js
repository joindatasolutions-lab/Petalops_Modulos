export const tenantConfig = {
  empresaId: 1,
  sucursalId: 1,
  apiBaseUrl: "https://join-flower-708265049038.us-central1.run.app"
};
