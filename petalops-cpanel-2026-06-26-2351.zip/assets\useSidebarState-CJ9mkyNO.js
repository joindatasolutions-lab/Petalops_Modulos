import{r as l,j as e}from"./index-UsULa73V.js";/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const j=(...a)=>a.filter((t,o,r)=>!!t&&t.trim()!==""&&r.indexOf(t)===o).join(" ").trim();/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const I=a=>a.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase();/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const _=a=>a.replace(/^([A-Z])|[\s-_]+(\w)/g,(t,o,r)=>r?r.toUpperCase():o.toLowerCase());/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const f=a=>{const t=_(a);return t.charAt(0).toUpperCase()+t.slice(1)};/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var g={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const A=a=>{for(const t in a)if(t.startsWith("aria-")||t==="role"||t==="title")return!0;return!1},K=l.createContext({}),S=()=>l.useContext(K),E=l.forwardRef(({color:a,size:t,strokeWidth:o,absoluteStrokeWidth:r,className:h="",children:n,iconNode:c,...d},p)=>{const{size:u=24,strokeWidth:s=2,absoluteStrokeWidth:y=!1,color:b="currentColor",className:m=""}=S()??{},x=r??y?Number(o??s)*24/Number(t??u):o??s;return l.createElement("svg",{ref:p,...g,width:t??u??g.width,height:t??u??g.height,stroke:a??b,strokeWidth:x,className:j("lucide",m,h),...!n&&!A(d)&&{"aria-hidden":"true"},...d},[...c.map(([k,M])=>l.createElement(k,M)),...Array.isArray(n)?n:[n]])});/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const i=(a,t)=>{const o=l.forwardRef(({className:r,...h},n)=>l.createElement(E,{ref:n,iconNode:t,className:j(`lucide-${I(f(a))}`,`lucide-${a}`,r),...h}));return o.displayName=f(a),o};/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const V=[["rect",{width:"8",height:"4",x:"8",y:"2",rx:"1",ry:"1",key:"tgr4d6"}],["path",{d:"M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2",key:"116196"}],["path",{d:"M12 11h4",key:"1jrz19"}],["path",{d:"M12 16h4",key:"n85exb"}],["path",{d:"M8 11h.01",key:"1dfujw"}],["path",{d:"M8 16h.01",key:"18s6g9"}]],z=i("clipboard-list",V);/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const P=[["path",{d:"M12 5a3 3 0 1 1 3 3m-3-3a3 3 0 1 0-3 3m3-3v1M9 8a3 3 0 1 0 3 3M9 8h1m5 0a3 3 0 1 1-3 3m3-3h-1m-2 3v-1",key:"3pnvol"}],["circle",{cx:"12",cy:"8",r:"2",key:"1822b1"}],["path",{d:"M12 10v12",key:"6ubwww"}],["path",{d:"M12 22c4.2 0 7-1.667 7-5-4.2 0-7 1.667-7 5Z",key:"9hd38g"}],["path",{d:"M12 22c-4.2 0-7-1.667-7-5 4.2 0 7 1.667 7 5Z",key:"ufn41s"}]],$=i("flower-2",P);/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const L=[["path",{d:"m16 17 5-5-5-5",key:"1bji2h"}],["path",{d:"M21 12H9",key:"dn1m92"}],["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}]],W=i("log-out",L);/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const T=[["path",{d:"M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",key:"1r0f0z"}],["circle",{cx:"12",cy:"10",r:"3",key:"ilqhr7"}]],O=i("map-pin",T);/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const R=[["path",{d:"M12 3v6",key:"1holv5"}],["path",{d:"M16.76 3a2 2 0 0 1 1.8 1.1l2.23 4.479a2 2 0 0 1 .21.891V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9.472a2 2 0 0 1 .211-.894L5.45 4.1A2 2 0 0 1 7.24 3z",key:"187q7i"}],["path",{d:"M3.054 9.013h17.893",key:"grwhos"}]],H=i("package-2",R);/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const q=[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}],["path",{d:"M9 3v18",key:"fh3hqa"}],["path",{d:"m16 15-3-3 3-3",key:"14y99z"}]],w=i("panel-left-close",q);/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const B=[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}],["path",{d:"M9 3v18",key:"fh3hqa"}],["path",{d:"m14 9 3 3-3 3",key:"8010ee"}]],N=i("panel-left-open",B);/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const U=[["path",{d:"M12 17V7",key:"pyj7ub"}],["path",{d:"M16 8h-6a2 2 0 0 0 0 4h4a2 2 0 0 1 0 4H8",key:"1elt7d"}],["path",{d:"M4 3a1 1 0 0 1 1-1 1.3 1.3 0 0 1 .7.2l.933.6a1.3 1.3 0 0 0 1.4 0l.934-.6a1.3 1.3 0 0 1 1.4 0l.933.6a1.3 1.3 0 0 0 1.4 0l.933-.6a1.3 1.3 0 0 1 1.4 0l.934.6a1.3 1.3 0 0 0 1.4 0l.933-.6A1.3 1.3 0 0 1 19 2a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1 1.3 1.3 0 0 1-.7-.2l-.933-.6a1.3 1.3 0 0 0-1.4 0l-.934.6a1.3 1.3 0 0 1-1.4 0l-.933-.6a1.3 1.3 0 0 0-1.4 0l-.933.6a1.3 1.3 0 0 1-1.4 0l-.934-.6a1.3 1.3 0 0 0-1.4 0l-.933.6a1.3 1.3 0 0 1-.7.2 1 1 0 0 1-1-1z",key:"ycz6yz"}]],D=i("receipt",U);/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const F=[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"M6.376 18.91a6 6 0 0 1 11.249.003",key:"hnjrf2"}],["circle",{cx:"12",cy:"11",r:"4",key:"1gt34v"}]],Z=i("shield-user",F);/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const G=[["path",{d:"M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2",key:"wrbu53"}],["path",{d:"M15 18H9",key:"1lyqi6"}],["path",{d:"M19 18h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.624l-3.48-4.35A1 1 0 0 0 17.52 8H14",key:"lysw3i"}],["circle",{cx:"17",cy:"18",r:"2",key:"332jqn"}],["circle",{cx:"7",cy:"18",r:"2",key:"19iecd"}]],Q=i("truck",G);/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Y=[["path",{d:"M18 21a8 8 0 0 0-16 0",key:"3ypg7q"}],["circle",{cx:"10",cy:"8",r:"5",key:"o932ke"}],["path",{d:"M22 20c0-3.37-2-6.5-4-8a5 5 0 0 0-.45-8.3",key:"10s06x"}]],J=i("users-round",Y);/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const X=[["rect",{width:"8",height:"8",x:"3",y:"3",rx:"2",key:"by2w9f"}],["path",{d:"M7 11v4a2 2 0 0 0 2 2h4",key:"xkn7yn"}],["rect",{width:"8",height:"8",x:"13",y:"13",rx:"2",key:"1cgmvn"}]],C=i("workflow",X),ee=[{key:"ventas",label:"VENTAS",items:[{key:"pipeline",label:"Pipeline",Icon:C,canViewKey:"pipeline",goKey:"pipeline"},{key:"pedidos",label:"Pedidos",Icon:z,canViewKey:"pedidos",goKey:"pedidos"}]},{key:"operaciones",label:"OPERACIONES",items:[{key:"produccion",label:"Producción",Icon:$,canViewKey:"produccion",goKey:"produccion"},{key:"domicilios",label:"Domicilios",Icon:Q,canViewKey:"domicilios",goKey:"domicilios"},{key:"barrios",label:"Barrios",Icon:O,canViewKey:"barrios",goKey:"barrios"},{key:"inventario",label:"Inventario",Icon:H,canViewKey:"inventario",goKey:"inventario"}]},{key:"administracion",label:"ADMINISTRACIÓN",items:[{key:"contabilidad",label:"Contabilidad",Icon:D,canViewKey:"contabilidad",goKey:"contabilidad"},{key:"trazabilidad",label:"Trazabilidad",Icon:C,canViewKey:"trazabilidad",goKey:"trazabilidad"},{key:"clientes",label:"Clientes",Icon:J,canViewKey:"clientes",goKey:"clientes"},{key:"usuarios",label:"Gestión usuarios",Icon:Z,canViewKey:"usuarios",goKey:"usuarios"}]}];function se({activeKey:a,sidebarPinned:t,sidebarMobileOpen:o,toggleSidebar:r,closeSidebarMobile:h,onLogout:n,permissions:c,navigation:d,badges:p={}}){const u=s=>{if(!(c!=null&&c[s.canViewKey]))return null;const y=a===s.key,b=Number(p==null?void 0:p[s.key]),m=Number.isFinite(b)&&b>0,x=s.Icon;return e.jsxs("button",{type:"button",className:`sidebar-nav-btn${y?" is-active":""}`,"data-label":s.label,onClick:()=>{var k;h==null||h(),(k=d==null?void 0:d[s.goKey])==null||k.call(d)},title:s.label,children:[e.jsx("span",{className:"sidebar-nav-icon",children:e.jsx(x,{size:20,strokeWidth:2})}),e.jsx("span",{className:"sidebar-nav-text",children:s.label}),m?e.jsx("span",{className:"sidebar-nav-badge",children:b}):null]},s.key)};return e.jsxs(e.Fragment,{children:[e.jsxs("aside",{className:"app-sidebar",children:[e.jsxs("div",{className:"sidebar-brand",children:[e.jsx("img",{src:"/logo.png",alt:"PetalOps",className:"sidebar-brand-logo-compact"}),e.jsx("img",{src:"/logo.png",alt:"",className:"sidebar-brand-logo-full"}),e.jsxs("div",{className:"sidebar-brand-wordmark",children:[e.jsx("strong",{children:"PetalOps"}),e.jsx("span",{children:"GESTION OPERATIVA"})]})]}),e.jsx("nav",{className:"sidebar-nav","aria-label":"Módulos",children:ee.map(s=>{const y=s.items.map(u).filter(Boolean);return y.length===0?null:e.jsxs("div",{className:"sidebar-nav-section",children:[e.jsx("p",{className:"sidebar-section-label",children:s.label}),e.jsx("div",{className:"sidebar-nav-group",children:y})]},s.key)})}),e.jsxs("div",{className:"sidebar-footer",children:[e.jsx("hr",{className:"sidebar-divider"}),e.jsxs("button",{type:"button",className:"sidebar-logout-btn",onClick:n,title:"Cerrar sesión","data-label":"Cerrar sesión",children:[e.jsx("span",{className:"sidebar-logout-icon","aria-hidden":"true",children:e.jsx(W,{size:20,strokeWidth:2})}),e.jsx("span",{className:"sidebar-logout-text",children:"Cerrar sesión"})]}),e.jsx("button",{type:"button",className:"sidebar-pin-btn",onClick:r,title:t?"Contraer menú":"Expandir menú","data-label":t?"Contraer menú":"Expandir menú",children:t?e.jsx(w,{size:20,strokeWidth:2}):e.jsx(N,{size:20,strokeWidth:2})})]})]}),e.jsx("button",{type:"button",className:"sidebar-mobile-fab","aria-label":o?"Cerrar menú":"Abrir menú",onClick:r,children:o?e.jsx(w,{size:21,strokeWidth:2}):e.jsx(N,{size:21,strokeWidth:2})}),e.jsx("button",{type:"button",className:"sidebar-overlay","aria-label":"Cerrar menú",onClick:h})]})}const v="petalops.sidebar.pinned";function ae(){var a;try{return((a=globalThis.localStorage)==null?void 0:a.getItem(v))==="true"}catch{return!1}}function re(){const[a,t]=l.useState(()=>ae()),[o,r]=l.useState(!1);return l.useEffect(()=>{var n;try{(n=globalThis.localStorage)==null||n.setItem(v,String(a))}catch{}},[a]),l.useEffect(()=>{const n=globalThis.matchMedia("(max-width: 980px)"),c=d=>{d.matches||r(!1)};return n.addEventListener("change",c),()=>n.removeEventListener("change",c)},[]),{sidebarPinned:a,sidebarMobileOpen:o,setSidebarMobileOpen:r,toggleSidebar:()=>{if(globalThis.matchMedia("(max-width: 980px)").matches){r(c=>!c);return}t(c=>!c)}}}export{se as A,z as C,$ as F,O as M,H as P,D as R,Q as T,J as U,i as c,re as u};
