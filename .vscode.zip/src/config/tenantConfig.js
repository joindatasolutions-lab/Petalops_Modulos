export const tenantConfig = {
  empresaId: 1,
  sucursalId: 1,
  apiBaseUrl: "/api"
};
