import{r as l,j as e}from"./index-CkrrZFdz.js";/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const C=(...t)=>t.filter((a,o,s)=>!!a&&a.trim()!==""&&s.indexOf(a)===o).join(" ").trim();/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const M=t=>t.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase();/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const _=t=>t.replace(/^([A-Z])|[\s-_]+(\w)/g,(a,o,s)=>s?s.toUpperCase():o.toLowerCase());/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const N=t=>{const a=_(t);return a.charAt(0).toUpperCase()+a.slice(1)};/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var f={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const I=t=>{for(const a in t)if(a.startsWith("aria-")||a==="role"||a==="title")return!0;return!1},A=l.createContext({}),K=()=>l.useContext(A),S=l.forwardRef(({color:t,size:a,strokeWidth:o,absoluteStrokeWidth:s,className:h="",children:n,iconNode:c,...d},u)=>{const{size:y=24,strokeWidth:k=2,absoluteStrokeWidth:r=!1,color:p="currentColor",className:b=""}=K()??{},x=s??r?Number(o??k)*24/Number(a??y):o??k;return l.createElement("svg",{ref:u,...f,width:a??y??f.width,height:a??y??f.height,stroke:t??p,strokeWidth:x,className:C("lucide",b,h),...!n&&!I(d)&&{"aria-hidden":"true"},...d},[...c.map(([g,m])=>l.createElement(g,m)),...Array.isArray(n)?n:[n]])});/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const i=(t,a)=>{const o=l.forwardRef(({className:s,...h},n)=>l.createElement(S,{ref:n,iconNode:a,className:C(`lucide-${M(N(t))}`,`lucide-${t}`,s),...h}));return o.displayName=N(t),o};/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const E=[["rect",{width:"8",height:"4",x:"8",y:"2",rx:"1",ry:"1",key:"tgr4d6"}],["path",{d:"M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2",key:"116196"}],["path",{d:"M12 11h4",key:"1jrz19"}],["path",{d:"M12 16h4",key:"n85exb"}],["path",{d:"M8 11h.01",key:"1dfujw"}],["path",{d:"M8 16h.01",key:"18s6g9"}]],V=i("clipboard-list",E);/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const z=[["path",{d:"M12 5a3 3 0 1 1 3 3m-3-3a3 3 0 1 0-3 3m3-3v1M9 8a3 3 0 1 0 3 3M9 8h1m5 0a3 3 0 1 1-3 3m3-3h-1m-2 3v-1",key:"3pnvol"}],["circle",{cx:"12",cy:"8",r:"2",key:"1822b1"}],["path",{d:"M12 10v12",key:"6ubwww"}],["path",{d:"M12 22c4.2 0 7-1.667 7-5-4.2 0-7 1.667-7 5Z",key:"9hd38g"}],["path",{d:"M12 22c-4.2 0-7-1.667-7-5 4.2 0 7 1.667 7 5Z",key:"ufn41s"}]],$=i("flower-2",z);/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const P=[["path",{d:"m16 17 5-5-5-5",key:"1bji2h"}],["path",{d:"M21 12H9",key:"dn1m92"}],["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}]],W=i("log-out",P);/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const L=[["path",{d:"M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",key:"1r0f0z"}],["circle",{cx:"12",cy:"10",r:"3",key:"ilqhr7"}]],T=i("map-pin",L);/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const O=[["path",{d:"M4 5h16",key:"1tepv9"}],["path",{d:"M4 12h16",key:"1lakjw"}],["path",{d:"M4 19h16",key:"1djgab"}]],R=i("menu",O);/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const H=[["path",{d:"M12 3v6",key:"1holv5"}],["path",{d:"M16.76 3a2 2 0 0 1 1.8 1.1l2.23 4.479a2 2 0 0 1 .21.891V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9.472a2 2 0 0 1 .211-.894L5.45 4.1A2 2 0 0 1 7.24 3z",key:"187q7i"}],["path",{d:"M3.054 9.013h17.893",key:"grwhos"}]],q=i("package-2",H);/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const B=[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}],["path",{d:"M9 3v18",key:"fh3hqa"}],["path",{d:"m16 15-3-3 3-3",key:"14y99z"}]],w=i("panel-left-close",B);/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const U=[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}],["path",{d:"M9 3v18",key:"fh3hqa"}],["path",{d:"m14 9 3 3-3 3",key:"8010ee"}]],D=i("panel-left-open",U);/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const F=[["path",{d:"M12 17V7",key:"pyj7ub"}],["path",{d:"M16 8h-6a2 2 0 0 0 0 4h4a2 2 0 0 1 0 4H8",key:"1elt7d"}],["path",{d:"M4 3a1 1 0 0 1 1-1 1.3 1.3 0 0 1 .7.2l.933.6a1.3 1.3 0 0 0 1.4 0l.934-.6a1.3 1.3 0 0 1 1.4 0l.933.6a1.3 1.3 0 0 0 1.4 0l.933-.6a1.3 1.3 0 0 1 1.4 0l.934.6a1.3 1.3 0 0 0 1.4 0l.933-.6A1.3 1.3 0 0 1 19 2a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1 1.3 1.3 0 0 1-.7-.2l-.933-.6a1.3 1.3 0 0 0-1.4 0l-.934.6a1.3 1.3 0 0 1-1.4 0l-.933-.6a1.3 1.3 0 0 0-1.4 0l-.933.6a1.3 1.3 0 0 1-1.4 0l-.934-.6a1.3 1.3 0 0 0-1.4 0l-.933.6a1.3 1.3 0 0 1-.7.2 1 1 0 0 1-1-1z",key:"ycz6yz"}]],Z=i("receipt",F);/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const G=[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"M6.376 18.91a6 6 0 0 1 11.249.003",key:"hnjrf2"}],["circle",{cx:"12",cy:"11",r:"4",key:"1gt34v"}]],Q=i("shield-user",G);/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Y=[["path",{d:"M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2",key:"wrbu53"}],["path",{d:"M15 18H9",key:"1lyqi6"}],["path",{d:"M19 18h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.624l-3.48-4.35A1 1 0 0 0 17.52 8H14",key:"lysw3i"}],["circle",{cx:"17",cy:"18",r:"2",key:"332jqn"}],["circle",{cx:"7",cy:"18",r:"2",key:"19iecd"}]],J=i("truck",Y);/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const X=[["path",{d:"M18 21a8 8 0 0 0-16 0",key:"3ypg7q"}],["circle",{cx:"10",cy:"8",r:"5",key:"o932ke"}],["path",{d:"M22 20c0-3.37-2-6.5-4-8a5 5 0 0 0-.45-8.3",key:"10s06x"}]],ee=i("users-round",X);/**
 * @license lucide-react v1.17.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ae=[["rect",{width:"8",height:"8",x:"3",y:"3",rx:"2",key:"by2w9f"}],["path",{d:"M7 11v4a2 2 0 0 0 2 2h4",key:"xkn7yn"}],["rect",{width:"8",height:"8",x:"13",y:"13",rx:"2",key:"1cgmvn"}]],j=i("workflow",ae),te=[{key:"ventas",label:"VENTAS",items:[{key:"pipeline",label:"Pipeline",Icon:j,canViewKey:"pipeline",goKey:"pipeline"},{key:"pedidos",label:"Pedidos",Icon:V,canViewKey:"pedidos",goKey:"pedidos"}]},{key:"operaciones",label:"OPERACIONES",items:[{key:"produccion",label:"Producción",Icon:$,canViewKey:"produccion",goKey:"produccion"},{key:"domicilios",label:"Domicilios",Icon:J,canViewKey:"domicilios",goKey:"domicilios"},{key:"barrios",label:"Barrios",Icon:T,canViewKey:"barrios",goKey:"barrios"},{key:"inventario",label:"Inventario",Icon:q,canViewKey:"inventario",goKey:"inventario"}]},{key:"administracion",label:"ADMINISTRACIÓN",items:[{key:"contabilidad",label:"Contabilidad",Icon:Z,canViewKey:"contabilidad",goKey:"contabilidad"},{key:"trazabilidad",label:"Trazabilidad",Icon:j,canViewKey:"trazabilidad",goKey:"trazabilidad"},{key:"clientes",label:"Clientes",Icon:ee,canViewKey:"clientes",goKey:"clientes"},{key:"usuarios",label:"Gestión usuarios",Icon:Q,canViewKey:"usuarios",goKey:"usuarios"}]}];function re({activeKey:t,sidebarPinned:a,sidebarMobileOpen:o,toggleSidebar:s,closeSidebarMobile:h,onLogout:n,permissions:c,navigation:d,badges:u={},sessionLabel:y=""}){const k=r=>{if(!(c!=null&&c[r.canViewKey]))return null;const p=t===r.key,b=Number(u==null?void 0:u[r.key]),x=Number.isFinite(b)&&b>0,g=r.Icon;return e.jsxs("button",{type:"button",className:`sidebar-nav-btn${p?" is-active":""}`,"data-label":r.label,onClick:()=>{var m;h==null||h(),(m=d==null?void 0:d[r.goKey])==null||m.call(d)},title:r.label,children:[e.jsx("span",{className:"sidebar-nav-icon",children:e.jsx(g,{size:20,strokeWidth:2})}),e.jsx("span",{className:"sidebar-nav-text",children:r.label}),x?e.jsx("span",{className:"sidebar-nav-badge",children:b}):null]},r.key)};return e.jsxs(e.Fragment,{children:[e.jsxs("aside",{className:"app-sidebar",children:[e.jsxs("div",{className:"sidebar-brand",children:[e.jsx("img",{src:"/logo.png",alt:"PetalOps",className:"sidebar-brand-logo-compact"}),e.jsx("img",{src:"/logo.png",alt:"",className:"sidebar-brand-logo-full"}),e.jsxs("div",{className:"sidebar-brand-wordmark",children:[e.jsx("strong",{children:"PetalOps"}),e.jsx("span",{children:"GESTION OPERATIVA"})]}),y?e.jsxs("span",{className:"sidebar-session-pill",children:[e.jsx("span",{className:"sidebar-session-dot","aria-hidden":"true"}),e.jsx("span",{className:"sidebar-session-text",children:y})]}):null]}),e.jsx("nav",{className:"sidebar-nav","aria-label":"Módulos",children:te.map(r=>{const p=r.items.map(k).filter(Boolean);return p.length===0?null:e.jsxs("div",{className:"sidebar-nav-section",children:[e.jsx("p",{className:"sidebar-section-label",children:r.label}),e.jsx("div",{className:"sidebar-nav-group",children:p})]},r.key)})}),e.jsxs("div",{className:"sidebar-footer",children:[e.jsx("hr",{className:"sidebar-divider"}),e.jsxs("button",{type:"button",className:"sidebar-logout-btn",onClick:n,title:"Cerrar sesión","data-label":"Cerrar sesión",children:[e.jsx("span",{className:"sidebar-logout-icon","aria-hidden":"true",children:e.jsx(W,{size:20,strokeWidth:2})}),e.jsx("span",{className:"sidebar-logout-text",children:"Cerrar sesión"})]}),e.jsx("button",{type:"button",className:"sidebar-pin-btn",onClick:s,title:a?"Contraer menú":"Expandir menú","data-label":a?"Contraer menú":"Expandir menú",children:a?e.jsx(w,{size:20,strokeWidth:2}):e.jsx(D,{size:20,strokeWidth:2})})]})]}),e.jsx("button",{type:"button",className:"sidebar-mobile-fab","aria-label":o?"Cerrar menú":"Abrir menú",onClick:s,children:o?e.jsx(w,{size:21,strokeWidth:2}):e.jsx(R,{size:21,strokeWidth:2})}),e.jsx("button",{type:"button",className:"sidebar-overlay","aria-label":"Cerrar menú",onClick:h})]})}const v="petalops.sidebar.pinned";function se(){var t;try{const a=(t=globalThis.localStorage)==null?void 0:t.getItem(v);return a==null?!0:a==="true"}catch{return!0}}function oe(){const[t,a]=l.useState(()=>se()),[o,s]=l.useState(!1);return l.useEffect(()=>{var n;try{(n=globalThis.localStorage)==null||n.setItem(v,String(t))}catch{}},[t]),l.useEffect(()=>{const n=globalThis.matchMedia("(max-width: 980px)"),c=d=>{d.matches||s(!1)};return n.addEventListener("change",c),()=>n.removeEventListener("change",c)},[]),{sidebarPinned:t,sidebarMobileOpen:o,setSidebarMobileOpen:s,toggleSidebar:()=>{if(globalThis.matchMedia("(max-width: 980px)").matches){s(c=>!c);return}a(c=>!c)}}}export{re as A,V as C,$ as F,T as M,q as P,Z as R,J as T,ee as U,i as c,oe as u};
